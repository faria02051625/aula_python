data = input("Digite uma data no formato dd/mm/aaaa: ")

partes = data.split("/")

if len(partes) != 3:
    print("Data inválida.")
else:
    dia = int(partes[0])
    mes = int(partes[1])
    ano = int(partes[2])

    data_valida = True

    if ano < 1 or mes < 1 or mes > 12 or dia < 1:
        data_valida = False
    else:
        if mes == 2:
            if (ano % 400 == 0) or (ano % 4 == 0 and ano % 100 != 0):
                max_dia = 29
            else:
                max_dia = 28
        elif mes == 4 or mes == 6 or mes == 9 or mes == 11:
            max_dia = 30
        else:
            max_dia = 31

        if dia > max_dia:
            data_valida = False

    if data_valida:
        print("Data válida.")
    else:
        print("Data inválida.")