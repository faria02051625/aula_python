tipo = input("Digite o tipo de carne (F - Filé Duplo / A - Alcatra / P - Picanha): ")
quantidade = float(input("Digite a quantidade em Kg: "))

if tipo == "F" or tipo == "f":
    carne = "Filé Duplo"
    if quantidade <= 5:
        preco_kg = 4.90
    else:
        preco_kg = 5.80

elif tipo == "A" or tipo == "a":
    carne = "Alcatra"
    if quantidade <= 5:
        preco_kg = 5.90
    else:
        preco_kg = 6.80

elif tipo == "P" or tipo == "p":
    carne = "Picanha"
    if quantidade <= 5:
        preco_kg = 6.90
    else:
        preco_kg = 7.80

else:
    print("Tipo de carne inválido.")
    carne = ""
    preco_kg = 0

if preco_kg > 0:
    total = quantidade * preco_kg
    print("Tipo de carne:", carne)
    print("Quantidade:", quantidade, "Kg")
    print("Preço total: R$", total)