respostas_positivas = 0

resposta = input("Telefonou para a vítima? (s/n): ")
if resposta == "s" or resposta == "S":
    respostas_positivas += 1

resposta = input("Esteve no local do crime? (s/n): ")
if resposta == "s" or resposta == "S":
    respostas_positivas += 1

resposta = input("Mora perto da vítima? (s/n): ")
if resposta == "s" or resposta == "S":
    respostas_positivas += 1

resposta = input("Devia para a vítima? (s/n): ")
if resposta == "s" or resposta == "S":
    respostas_positivas += 1

resposta = input("Já trabalhou com a vítima? (s/n): ")
if resposta == "s" or resposta == "S":
    respostas_positivas += 1

if respostas_positivas == 2:
    print("Classificação: Suspeita")
elif respostas_positivas == 3 or respostas_positivas == 4:
    print("Classificação: Cúmplice")
elif respostas_positivas == 5:
    print("Classificação: Assassino")
else:
    print("Classificação: Inocente")