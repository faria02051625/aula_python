preco1 = float(input("Digite o preço do primeiro produto: "))
preco2 = float(input("Digite o preço do segundo produto: "))
preco3 = float(input("Digite o preço do terceiro produto: "))

menor = preco1
produto = "primeiro produto"

if preco2 < menor:
    menor = preco2
    produto = "segundo produto"

if preco3 < menor:
    menor = preco3
    produto = "terceiro produto"

print("Você deve comprar o", produto)
print("Preço:", menor)