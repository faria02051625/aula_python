litros = float(input("Digite a quantidade de litros vendidos: "))
tipo = input("Digite o tipo de combustível (A para álcool / G para gasolina): ")

if tipo == "A" or tipo == "a":
    preco_litro = 1.90
    if litros <= 20:
        desconto = 0.03
    else:
        desconto = 0.05

elif tipo == "G" or tipo == "g":
    preco_litro = 2.50
    if litros <= 20:
        desconto = 0.04
    else:
        desconto = 0.06

else:
    print("Tipo de combustível inválido.")
    preco_litro = 0
    desconto = 0

if preco_litro > 0:
    valor_bruto = litros * preco_litro
    valor_desconto = valor_bruto * desconto
    valor_final = valor_bruto - valor_desconto

    print("Valor bruto: R$", valor_bruto)
    print("Desconto: R$", valor_desconto)
    print("Valor a pagar: R$", valor_final)