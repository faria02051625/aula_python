valor = int(input("Digite o valor do saque: "))

if valor < 10 or valor > 600:
    print("Valor inválido. O saque deve ser entre 10 e 600 reais.")
else:
    notas100 = valor // 100
    resto = valor % 100

    notas50 = resto // 50
    resto = resto % 50

    notas10 = resto // 10
    resto = resto % 10

    notas5 = resto // 5
    resto = resto % 5

    notas1 = resto

    print("Notas fornecidas:")
    if notas100 > 0:
        print("Notas de 100:", notas100)
    if notas50 > 0:
        print("Notas de 50:", notas50)
    if notas10 > 0:
        print("Notas de 10:", notas10)
    if notas5 > 0:
        print("Notas de 5:", notas5)
    if notas1 > 0:
        print("Notas de 1:", notas1)