kg_morango = float(input("Digite a quantidade de morangos (Kg): "))
kg_maca = float(input("Digite a quantidade de maçãs (Kg): "))

if kg_morango <= 5:
    preco_morango = 2.50
else:
    preco_morango = 2.20

if kg_maca <= 5:
    preco_maca = 1.80
else:
    preco_maca = 1.50

valor_morango = kg_morango * preco_morango
valor_maca = kg_maca * preco_maca
valor_total = valor_morango + valor_maca

print("Valor dos morangos: R$", valor_morango)
print("Valor das maçãs: R$", valor_maca)
print("Valor total: R$", valor_total)