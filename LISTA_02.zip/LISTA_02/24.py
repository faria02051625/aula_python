numero = int(input("Digite um número menor que 1000: "))

centena = numero // 100
dezena = (numero % 100) // 10
unidade = numero % 10

partes = []

if centena > 0:
    if centena == 1:
        partes.append("1 centena")
    else:
        partes.append(f"{centena} centenas")

if dezena > 0:
    if dezena == 1:
        partes.append("1 dezena")
    else:
        partes.append(f"{dezena} dezenas")

if unidade > 0:
    if unidade == 1:
        partes.append("1 unidade")
    else:
        partes.append(f"{unidade} unidades")

# Montar a frase corretamente
if len(partes) == 3:
    resultado = f"{partes[0]}, {partes[1]} e {partes[2]}"
elif len(partes) == 2:
    resultado = f"{partes[0]} e {partes[1]}"
elif len(partes) == 1:
    resultado = partes[0]
else:
    resultado = "0"

print(f"{numero} = {resultado}")