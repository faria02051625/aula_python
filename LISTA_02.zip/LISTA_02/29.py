numero1 = float(input("Digite o primeiro número: "))
numero2 = float(input("Digite o segundo número: "))

print("Escolha a operação:")
print("1 - Soma")
print("2 - Subtração")
print("3 - Multiplicação")
print("4 - Divisão")

opcao = input("Digite a opção desejada: ")

if opcao == "1":
    resultado = numero1 + numero2
    operacao = "soma"
elif opcao == "2":
    resultado = numero1 - numero2
    operacao = "subtração"
elif opcao == "3":
    resultado = numero1 * numero2
    operacao = "multiplicação"
elif opcao == "4":
    resultado = numero1 / numero2
    operacao = "divisão"
else:
    print("Opção inválida.")
    resultado = None

if resultado is not None:
    print("Resultado da", operacao + ":", resultado)

    if resultado == int(resultado):
        tipo = "inteiro"
    else:
        tipo = "decimal"

    if resultado > 0:
        sinal = "positivo"
    elif resultado < 0:
        sinal = "negativo"
    else:
        sinal = "zero"

    if resultado == int(resultado):
        if int(resultado) % 2 == 0:
            paridade = "par"
        else:
            paridade = "ímpar"
    else:
        paridade = "não se aplica, pois é decimal"

    print("Paridade:", paridade)
    print("Sinal:", sinal)
    print("Tipo:", tipo)