altura = float(input("Digite sua altura: "))
peso_ideal = (72.7 * altura) - 58

print("O peso ideal é:", peso_ideal)