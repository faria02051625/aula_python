import math

area = float(input("Digite o tamanho da área a ser pintada em metros quadrados: "))

litros_necessarios = area / 3
latas = math.ceil(litros_necessarios / 18)
preco_total = latas * 80

print("Quantidade de latas:", latas)
print("Preço total: R$", preco_total)