ganho_por_hora = float(input("Quanto você ganha por hora? "))
horas_trabalhadas = float(input("Quantas horas você trabalhou no mês? "))

salario = ganho_por_hora * horas_trabalhadas

print("O salário no mês é:", salario)