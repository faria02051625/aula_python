import math

area = float(input("Digite o tamanho da área a ser pintada em metros quadrados: "))

litros_necessarios = area / 6

litros_com_folga = litros_necessarios * 1.10

latas = math.ceil(litros_com_folga / 18)
preco_latas = latas * 80

galoes = math.ceil(litros_com_folga / 3.6)
preco_galoes = galoes * 25

latas_mistura = int(litros_com_folga // 18)
resto = litros_com_folga - (latas_mistura * 18)
galoes_mistura = math.ceil(resto / 3.6)

if resto == 0:
    galoes_mistura = 0

preco_mistura = (latas_mistura * 80) + (galoes_mistura * 25)

print("\nSituação 1 - Apenas latas de 18L")
print("Quantidade de latas:", latas)
print("Preço total: R$", preco_latas)

print("\nSituação 2 - Apenas galões de 3,6L")
print("Quantidade de galões:", galoes)
print("Preço total: R$", preco_galoes)

print("\nSituação 3 - Mistura de latas e galões")
print("Quantidade de latas:", latas_mistura)
print("Quantidade de galões:", galoes_mistura)
print("Preço total: R$", preco_mistura)