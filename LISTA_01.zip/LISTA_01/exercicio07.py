lado = float(input("Digite o lado do quadrado: "))
area = lado ** 2
dobro = area * 2

print("O dobro da área do quadrado é:", dobro)