import math

area = float(input("Digite o tamanho da área a ser pintada em metros quadrados: "))

litros_necessarios = area / 6

latas = math.ceil(litros_necessarios / 18)
preco_latas = latas * 80

galoes = math.ceil(litros_necessarios / 3.6)
preco_galoes = galoes * 25

print("Quantidade usando apenas latas de 18L:", latas)
print("Preço usando apenas latas: R$", preco_latas)

print("Quantidade usando apenas galões de 3,6L:", galoes)
print("Preço usando apenas galões: R$", preco_galoes)