altura = float(input("Digite a altura: "))
sexo = input("Digite o sexo (M para homem / F para mulher): ")

if sexo == "M" or sexo == "m":
    peso_ideal = (72.7 * altura) - 58
elif sexo == "F" or sexo == "f":
    peso_ideal = (62.1 * altura) - 44.7
else:
    print("Sexo inválido.")
    peso_ideal = None

if peso_ideal is not None:
    print("O peso ideal é:", peso_ideal)