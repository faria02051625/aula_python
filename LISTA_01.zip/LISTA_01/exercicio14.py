peso = float(input("Digite o peso de peixes: "))

if peso > 50:
    excesso = peso - 50
    multa = excesso * 4
else:
    excesso = 0
    multa = 0

print("Peso de peixes:", peso, "kg")
print("Excesso:", excesso, "kg")
print("Multa: R$", multa)