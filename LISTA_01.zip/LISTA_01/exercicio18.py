tamanho_arquivo = float(input("Digite o tamanho do arquivo (MB): "))
velocidade = float(input("Digite a velocidade da internet (Mbps): "))

tamanho_megabits = tamanho_arquivo * 8

tempo_segundos = tamanho_megabits / velocidade
tempo_minutos = tempo_segundos / 60

print("Tempo aproximado de download:", tempo_minutos, "minutos")