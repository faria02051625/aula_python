inteiro1 = int(input("Digite o primeiro número inteiro: "))
inteiro2 = int(input("Digite o segundo número inteiro: "))
real = float(input("Digite um número real: "))

a = (inteiro1 * 2) * (inteiro2 / 2)
b = (inteiro1 * 3) + real
c = real ** 3

print("a) Produto do dobro do primeiro com metade do segundo:", a)
print("b) Soma do triplo do primeiro com o terceiro:", b)
print("c) Terceiro elevado ao cubo:", c)