populacao_a = 80000
populacao_b = 200000
anos = 0

while populacao_a < populacao_b:
    populacao_a = populacao_a + (populacao_a * 0.03)
    populacao_b = populacao_b + (populacao_b * 0.015)
    anos += 1

print("Número de anos necessários:", anos)
print("População final de A:", int(populacao_a))
print("População final de B:", int(populacao_b))