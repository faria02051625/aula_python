divida = float(input("Digite o valor da dívida: R$ "))

print("\nValor da Dívida | Valor dos Juros | Quantidade de Parcelas | Valor da Parcela")

parcelas = [1, 3, 6, 9, 12]
juros_percentuais = [0, 10, 15, 20, 25]

for i in range(len(parcelas)):
    juros = divida * (juros_percentuais[i] / 100)
    valor_total = divida + juros
    valor_parcela = valor_total / parcelas[i]

    print(f"R$ {valor_total:8.2f} | R$ {juros:8.2f} | {parcelas[i]:21} | R$ {valor_parcela:8.2f}")