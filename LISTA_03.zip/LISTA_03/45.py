v = [0] * 7

while True:
    x = int(input("Vote (1-José, 2-João, 3-Maria, 4-Ana, 5-Nulo, 6-Branco, 0-Fim): "))
    if x == 0:
        break
    if 1 <= x <= 6:
        v[x] += 1

total = sum(v)
print(f"José: {v[1]}\nJoão: {v[2]}\nMaria: {v[3]}\nAna: {v[4]}")
print(f"Nulos: {v[5]}\nBrancos: {v[6]}")
print(f"% Nulos: {(v[5]/total*100 if total else 0):.2f}%")
print(f"% Brancos: {(v[6]/total*100 if total else 0):.2f}%")