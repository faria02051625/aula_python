num1 = int(input("Digite o primeiro número inteiro: "))
num2 = int(input("Digite o segundo número inteiro: "))

inicio = min(num1, num2)
fim = max(num1, num2)
soma = 0

for i in range(inicio, fim + 1):
    print(i)
    soma += i

print("Soma dos números:", soma)