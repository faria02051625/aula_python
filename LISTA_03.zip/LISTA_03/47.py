while True:
    nome = input("Atleta: ")

    if nome == "":
        break

    saltos = []

    for i in range(5):
        salto = float(input(f"{i+1}º Salto: "))
        saltos.append(salto)

    melhor = max(saltos)
    pior = min(saltos)

    soma = 0
    tirou_melhor = False
    tirou_pior = False

    for salto in saltos:
        if salto == melhor and tirou_melhor == False:
            tirou_melhor = True
        elif salto == pior and tirou_pior == False:
            tirou_pior = True
        else:
            soma = soma + salto

    media = soma / 3

    print("\nResultado final:")
    print(nome)
    print("Saltos:", saltos)
    print("Melhor salto:", melhor, "m")
    print("Pior salto:", pior, "m")
    print("Média dos demais saltos:", media, "m")
    print(nome + ":", media, "m\n")