n = int(input("Digite um número inteiro N: "))

divisoes = 0

print(f"Números primos entre 1 e {n}:")

for numero in range(2, n + 1):
    primo = True

    for i in range(2, numero):
        divisoes += 1
        if numero % i == 0:
            primo = False
            break

    if primo:
        print(numero)

print("Quantidade de divisões executadas:", divisoes)