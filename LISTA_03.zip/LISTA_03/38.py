maior_altura = 0
menor_altura = 0
maior_peso = 0
menor_peso = 0

codigo_mais_alto = 0
codigo_mais_baixo = 0
codigo_mais_gordo = 0
codigo_mais_magro = 0

soma_alturas = 0
soma_pesos = 0
quantidade = 0

while True:
    codigo = int(input("Digite o código do cliente (0 para encerrar): "))

    if codigo == 0:
        break

    altura = float(input("Digite a altura do cliente: "))
    peso = float(input("Digite o peso do cliente: "))

    if quantidade == 0:
        maior_altura = altura
        menor_altura = altura
        maior_peso = peso
        menor_peso = peso

        codigo_mais_alto = codigo
        codigo_mais_baixo = codigo
        codigo_mais_gordo = codigo
        codigo_mais_magro = codigo
    else:
        if altura > maior_altura:
            maior_altura = altura
            codigo_mais_alto = codigo

        if altura < menor_altura:
            menor_altura = altura
            codigo_mais_baixo = codigo

        if peso > maior_peso:
            maior_peso = peso
            codigo_mais_gordo = codigo

        if peso < menor_peso:
            menor_peso = peso
            codigo_mais_magro = codigo

    soma_alturas += altura
    soma_pesos += peso
    quantidade += 1

if quantidade > 0:
    media_alturas = soma_alturas / quantidade
    media_pesos = soma_pesos / quantidade

    print("\nCliente mais alto:")
    print("Código:", codigo_mais_alto)
    print("Altura:", maior_altura)

    print("\nCliente mais baixo:")
    print("Código:", codigo_mais_baixo)
    print("Altura:", menor_altura)

    print("\nCliente mais gordo:")
    print("Código:", codigo_mais_gordo)
    print("Peso:", maior_peso)

    print("\nCliente mais magro:")
    print("Código:", codigo_mais_magro)
    print("Peso:", menor_peso)

    print("\nMédia das alturas:", media_alturas)
    print("Média dos pesos:", media_pesos)
else:
    print("Nenhum cliente foi informado.")