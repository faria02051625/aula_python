numero = int(input("Montar a tabuada de: "))
inicio = int(input("Começar por: "))
fim = int(input("Terminar em: "))

while fim < inicio:
    print("Erro: o valor final não pode ser menor que o valor inicial.")
    inicio = int(input("Começar por: "))
    fim = int(input("Terminar em: "))

print(f"\nVou montar a tabuada de {numero} começando em {inicio} e terminando em {fim}:")

for i in range(inicio, fim + 1):
    print(f"{numero} X {i} = {numero * i}")