quantidade = int(input("Digite a quantidade de notas: "))

soma = 0

for i in range(quantidade):
    nota = float(input(f"Digite a {i+1}ª nota: "))
    soma += nota

media = soma / quantidade

print("Média aritmética:", media)