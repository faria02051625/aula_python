cont_0_25 = 0
cont_26_50 = 0
cont_51_75 = 0
cont_76_100 = 0

while True:
    num = float(input("Digite um número: "))

    if num < 0:
        break
    elif 0 <= num <= 25:
        cont_0_25 += 1
    elif 26 <= num <= 50:
        cont_26_50 += 1
    elif 51 <= num <= 75:
        cont_51_75 += 1
    elif 76 <= num <= 100:
        cont_76_100 += 1

print("Quantidade no intervalo [0-25]:", cont_0_25)
print("Quantidade no intervalo [26-50]:", cont_26_50)
print("Quantidade no intervalo [51-75]:", cont_51_75)
print("Quantidade no intervalo [76-100]:", cont_76_100)