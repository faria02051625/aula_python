numero = int(input("Fatorial de: "))

fatorial = 1

print(f"{numero}! = ", end="")

for i in range(numero, 0, -1):
    fatorial *= i
    print(i, end="")

    if i > 1:
        print(" . ", end="")

print(f" = {fatorial}")