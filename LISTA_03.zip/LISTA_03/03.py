while True:
    nome = input("Digite o nome: ")
    if len(nome) > 3:
        break
    print("Nome inválido. Deve ter mais de 3 caracteres.")

while True:
    idade = int(input("Digite a idade: "))
    if 0 <= idade <= 150:
        break
    print("Idade inválida. Deve estar entre 0 e 150.")

while True:
    salario = float(input("Digite o salário: "))
    if salario > 0:
        break
    print("Salário inválido. Deve ser maior que zero.")

while True:
    sexo = input("Digite o sexo (f/m): ").lower()
    if sexo == "f" or sexo == "m":
        break
    print("Sexo inválido. Digite 'f' ou 'm'.")

while True:
    estado_civil = input("Digite o estado civil (s/c/v/d): ").lower()
    if estado_civil in ["s", "c", "v", "d"]:
        break
    print("Estado civil inválido. Digite 's', 'c', 'v' ou 'd'.")

print("\nDados válidos informados:")
print("Nome:", nome)
print("Idade:", idade)
print("Salário:", salario)
print("Sexo:", sexo)
print("Estado civil:", estado_civil)