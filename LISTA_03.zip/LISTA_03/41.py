maior = menor = None
cid_maior = cid_menor = 0
soma_veiculos = soma_acidentes_2000 = cont_2000 = 0

for _ in range(5):
    codigo = int(input("Código: "))
    veiculos = int(input("Veículos: "))
    acidentes = int(input("Acidentes: "))

    indice = acidentes / veiculos
    soma_veiculos += veiculos

    if maior is None or indice > maior:
        maior, cid_maior = indice, codigo

    if menor is None or indice < menor:
        menor, cid_menor = indice, codigo

    if veiculos < 2000:
        soma_acidentes_2000 += acidentes
        cont_2000 += 1

print("\nMaior índice:", maior, "Cidade:", cid_maior)
print("Menor índice:", menor, "Cidade:", cid_menor)
print("Média de veículos:", soma_veiculos / 5)

if cont_2000:
    print("Média acidentes (<2000 veículos):", soma_acidentes_2000 / cont_2000)
else:
    print("Sem cidades com menos de 2000 veículos.")