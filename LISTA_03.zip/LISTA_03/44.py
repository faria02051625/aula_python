cardapio = {
    100: ("Cachorro Quente", 1.20),
    101: ("Bauru Simples", 1.30),
    102: ("Bauru com ovo", 1.50),
    103: ("Hambúrguer", 1.20),
    104: ("Cheeseburguer", 1.30),
    105: ("Refrigerante", 1.00)
}

total_geral = 0

while True:
    entrada = input("Digite o código do item ou F para encerrar: ")

    if entrada.upper() == "F":
        break

    codigo = int(entrada)

    if codigo not in cardapio:
        print("Código inválido.")
        continue

    quantidade = int(input("Digite a quantidade: "))

    nome, preco = cardapio[codigo]
    total_item = preco * quantidade
    total_geral += total_item

    print(f"{nome} - Valor: R$ {total_item:.2f}")

print(f"Total geral do pedido: R$ {total_geral:.2f}")