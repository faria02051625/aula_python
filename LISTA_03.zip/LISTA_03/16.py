a = 0
b = 1

while a <= 500:
    print(a, end=" ")
    proximo = a + b
    a = b
    b = proximo