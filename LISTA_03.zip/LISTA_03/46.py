gabarito = ["A", "B", "C", "D", "E", "E", "D", "C", "B", "A"]

total_alunos = 0
soma_notas = 0
maior = -1
menor = 11

resposta = "S"

while resposta == "S":
    acertos = 0

    for i in range(10):
        r = input(f"Resposta da questão {i+1}: ").upper()

        if r == gabarito[i]:
            acertos = acertos + 1

    print("Nota do aluno:", acertos)

    total_alunos = total_alunos + 1
    soma_notas = soma_notas + acertos

    if acertos > maior:
        maior = acertos

    if acertos < menor:
        menor = acertos

    resposta = input("Outro aluno vai usar o sistema? (S/N): ").upper()

media = soma_notas / total_alunos

print("Maior acerto:", maior)
print("Menor acerto:", menor)
print("Total de alunos:", total_alunos)
print("Média da turma:", media)