while True:
   
    while True:
        populacao_a = int(input("Digite a população do país A: "))
        if populacao_a > 0:
            break
        print("Valor inválido. A população deve ser maior que zero.")

   
    while True:
        populacao_b = int(input("Digite a população do país B: "))
        if populacao_b > 0:
            break
        print("Valor inválido. A população deve ser maior que zero.")

  
    while True:
        taxa_a = float(input("Digite a taxa de crescimento do país A (%): "))
        if taxa_a > 0:
            taxa_a = taxa_a / 100
            break
        print("Valor inválido. A taxa deve ser maior que zero.")

   
    while True:
        taxa_b = float(input("Digite a taxa de crescimento do país B (%): "))
        if taxa_b > 0:
            taxa_b = taxa_b / 100
            break
        print("Valor inválido. A taxa deve ser maior que zero.")

    anos = 0
    pa = populacao_a
    pb = populacao_b

    while pa < pb:
        pa = pa + (pa * taxa_a)
        pb = pb + (pb * taxa_b)
        anos += 1

    print("\nResultado:")
    print("Anos necessários:", anos)
    print("População final de A:", int(pa))
    print("População final de B:", int(pb))

    repetir = input("\nDeseja repetir a operação? (s/n): ").lower()
    if repetir != "s":
        print("Programa encerrado.")
        break