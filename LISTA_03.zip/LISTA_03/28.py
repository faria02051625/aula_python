quantidade_cds = int(input("Digite a quantidade de CDs: "))

total_investido = 0

for i in range(quantidade_cds):
    valor = float(input(f"Digite o valor do CD {i+1}: R$ "))
    total_investido += valor

media = total_investido / quantidade_cds

print("Valor total investido: R$", total_investido)
print("Valor médio gasto em cada CD: R$", media)