quantidade = int(input("Digite a quantidade de temperaturas: "))

menor = None
maior = None
soma = 0

for i in range(quantidade):
    temperatura = float(input(f"Digite a {i+1}ª temperatura: "))

    if menor is None or temperatura < menor:
        menor = temperatura

    if maior is None or temperatura > maior:
        maior = temperatura

    soma += temperatura

media = soma / quantidade

print("Menor temperatura:", menor)
print("Maior temperatura:", maior)
print("Média das temperaturas:", media)