numero = int(input("Digite um número inteiro para calcular o fatorial: "))

fatorial = 1

for i in range(numero, 0, -1):
    fatorial *= i

print(f"{numero}! = {fatorial}")