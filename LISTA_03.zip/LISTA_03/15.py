n = int(input("Digite a quantidade de termos da série de Fibonacci: "))

a = 1
b = 1

if n <= 0:
    print("Digite um número maior que zero.")
elif n == 1:
    print(a)
elif n == 2:
    print(a, b)
else:
    print(a, b, end=" ")
    for i in range(3, n + 1):
        proximo = a + b
        print(proximo, end=" ")
        a = b
        b = proximo