salario = 1000.00
percentual = 0.015

for ano in range(1996, 2026 + 1):
    salario += salario * percentual
    percentual *= 2

print(f"Salário atual: R$ {salario:.2f}")