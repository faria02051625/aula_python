n = int(input("Digite a quantidade de termos: "))

soma = 0

print("S = ", end="")

for i in range(1, n + 1):
    denominador = 2 * i - 1
    soma += i / denominador

    print(f"{i}/{denominador}", end="")
    if i < n:
        print(" + ", end="")

print(f"\nSoma da série = {soma:.2f}")