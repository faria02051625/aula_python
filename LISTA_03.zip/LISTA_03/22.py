numero = int(input("Digite um número inteiro: "))

if numero <= 1:
    print("Não é um número primo.")
else:
    divisores = []

    for i in range(2, numero):
        if numero % i == 0:
            divisores.append(i)

    if len(divisores) == 0:
        print("É um número primo.")
    else:
        print("Não é um número primo.")
        print("Ele é divisível por:", end=" ")
        
        for i in range(len(divisores)):
            if i < len(divisores) - 1:
                print(divisores[i], end=", ")
            else:
                print(divisores[i])