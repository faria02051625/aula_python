nome = input("Atleta: ")

notas = []

for i in range(7):
    nota = float(input("Nota: "))
    notas.append(nota)

maior = max(notas)
menor = min(notas)

soma = 0
tirou_maior = False
tirou_menor = False

for nota in notas:
    if nota == maior and tirou_maior == False:
        tirou_maior = True
    elif nota == menor and tirou_menor == False:
        tirou_menor = True
    else:
        soma = soma + nota

media = soma / 5

print("\nResultado final:")
print("Atleta:", nome)
print("Melhor nota:", maior)
print("Pior nota:", menor)
print("Média:", round(media, 2))