quantidade = int(input("Digite a quantidade de números: "))

menor = None
maior = None
soma = 0

for i in range(quantidade):
    while True:
        numero = float(input(f"Digite o {i+1}º número (entre 0 e 1000): "))

        if 0 <= numero <= 1000:
            break
        else:
            print("Valor inválido. Digite um número entre 0 e 1000.")

    if menor is None or numero < menor:
        menor = numero

    if maior is None or numero > maior:
        maior = numero

    soma += numero

print("Menor valor:", menor)
print("Maior valor:", maior)
print("Soma dos valores:", soma)