quantidade = int(input("Digite a quantidade de pessoas: "))

soma_idades = 0

for i in range(quantidade):
    idade = int(input(f"Digite a idade da {i+1}ª pessoa: "))
    soma_idades += idade

media = soma_idades / quantidade

print("Média de idade da turma:", media)

if 0 <= media <= 25:
    print("A turma é jovem.")
elif 26 <= media <= 60:
    print("A turma é adulta.")
else:
    print("A turma é idosa.")