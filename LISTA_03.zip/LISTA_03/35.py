numero = int(input("Digite um número inteiro: "))

print(f"Números primos entre 1 e {numero}:")

for n in range(2, numero + 1):
    primo = True

    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            primo = False
            break

    if primo:
        print(n)