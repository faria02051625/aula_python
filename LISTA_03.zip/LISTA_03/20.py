while True:
    while True:
        numero = int(input("Digite um número inteiro positivo menor que 16: "))
        
        if 0 <= numero < 16:
            break
        else:
            print("Valor inválido. Digite um número entre 0 e 15.")

    fatorial = 1

    print(f"{numero}! = ", end="")

    for i in range(numero, 0, -1):
        fatorial *= i
        print(i, end="")
        
        if i > 1:
            print(" x ", end="")

    print(f" = {fatorial}")

    repetir = input("\nDeseja calcular outro fatorial? (s/n): ").lower()
    if repetir != "s":
        print("Programa encerrado.")
        break