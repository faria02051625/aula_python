total_eleitores = int(input("Digite o número total de eleitores: "))

votos_candidato1 = 0
votos_candidato2 = 0
votos_candidato3 = 0

for i in range(total_eleitores):
    while True:
        voto = int(input(f"Eleitor {i+1}, vote no candidato (1, 2 ou 3): "))

        if voto == 1:
            votos_candidato1 += 1
            break
        elif voto == 2:
            votos_candidato2 += 1
            break
        elif voto == 3:
            votos_candidato3 += 1
            break
        else:
            print("Voto inválido. Digite 1, 2 ou 3.")

print("\nResultado da eleição:")
print("Candidato 1:", votos_candidato1, "votos")
print("Candidato 2:", votos_candidato2, "votos")
print("Candidato 3:", votos_candidato3, "votos")