quantidade_turmas = int(input("Digite a quantidade de turmas: "))

total_alunos = 0

for i in range(quantidade_turmas):
    while True:
        alunos = int(input(f"Digite a quantidade de alunos da turma {i+1}: "))

        if 0 <= alunos <= 40:
            total_alunos += alunos
            break
        else:
            print("Valor inválido. Cada turma pode ter no máximo 40 alunos.")

media = total_alunos / quantidade_turmas

print("Número médio de alunos por turma:", media)