numero_mais_alto = 0
altura_mais_alta = 0

numero_mais_baixo = 0
altura_mais_baixa = 0

for i in range(10):
    numero_aluno = int(input(f"Digite o número do {i+1}º aluno: "))
    altura = float(input(f"Digite a altura do {i+1}º aluno em cm: "))

    if i == 0:
        numero_mais_alto = numero_aluno
        altura_mais_alta = altura
        numero_mais_baixo = numero_aluno
        altura_mais_baixa = altura
    else:
        if altura > altura_mais_alta:
            altura_mais_alta = altura
            numero_mais_alto = numero_aluno

        if altura < altura_mais_baixa:
            altura_mais_baixa = altura
            numero_mais_baixo = numero_aluno

print("\nAluno mais alto:")
print("Número:", numero_mais_alto)
print("Altura:", altura_mais_alta, "cm")

print("\nAluno mais baixo:")
print("Número:", numero_mais_baixo)
print("Altura:", altura_mais_baixa, "cm")